import { JsonRpcProvider, FetchRequest, Contract, getAddress, formatUnits } from 'ethers';
import { NETWORK } from '../src/network.js';

export const ABI = {
  tm: ['function borrowerOperations() view returns(address)', 'function collSurplusPool() view returns(address)', 'function musdToken() view returns(address)', 'function getTroveStatus(address) view returns(uint8)', 'function getEntireDebtAndColl(address) view returns(uint256 coll,uint256 principal,uint256 interest,uint256 pendingCollateral,uint256 pendingPrincipal,uint256 pendingInterest)'],
  bo: ['function troveManager() view returns(address)', 'function collSurplusPool() view returns(address)', 'function claimCollateral()'],
  pool: ['function borrowerOperationsAddress() view returns(address)', 'function troveManagerAddress() view returns(address)', 'function getCollateral(address) view returns(uint256)'],
  token: ['function balanceOf(address) view returns(uint256)', 'function decimals() view returns(uint8)'],
};
export function describeStatus(status, surplus) {
  const states = [
    ['No loan on record', 'The protocol reports no loan for this address. This does not prove that the wallet has never used another address or another deployment.'],
    ['Loan is active', 'Your MUSD loan is still open. This check does not establish whether a partial redemption happened.'],
    ['Closed by owner', 'The protocol records this loan as closed by its owner, not by redemption or liquidation.'],
    ['Closed by liquidation', 'The protocol records a liquidation. This is different from a redemption; this app cannot reverse it.'],
    ['Closed by redemption', 'The protocol records a full redemption: MUSD was exchanged against the loan, closing it. Any remaining collateral must be checked separately.'],
  ];
  const [title, explanation] = states[status] || ['Unknown loan state', 'This status is not recognized. Do not assume a cause or sign a transaction.'];
  return { title, explanation, hasSurplus: BigInt(surplus) > 0n, recognized: status >= 0 && status <= 4 };
}
const same = (a,b) => a.toLowerCase() === b.toLowerCase();
export async function withProvider(fn) {
  let last;
  for (const url of [NETWORK.rpcUrl, 'https://mezo-mainnet.boar.network']) {
    const request = new FetchRequest(url); request.timeout = 12000;
    const provider = new JsonRpcProvider(request, NETWORK.chainId, { staticNetwork: true, batchMaxCount: 10, batchStallTime: 20 });
    try { return await fn(provider); } catch (e) { last = e; } finally { provider.destroy(); }
  }
  throw last;
}
export async function verifyDeployment(provider, blockTag) {
  if (Number(BigInt(await provider.send('eth_chainId', []))) !== NETWORK.chainId) throw new Error('Wrong chain returned by RPC.');
  const c = NETWORK.contracts;
  const codes = await Promise.all(Object.values(c).map(a => provider.getCode(a, blockTag)));
  if (codes.some(code => code === '0x')) throw new Error('Expected contract code was not found.');
  const tm = new Contract(c.troveManager, ABI.tm, provider);
  const bo = new Contract(c.borrowerOperations, ABI.bo, provider);
  const pool = new Contract(c.collSurplusPool, ABI.pool, provider);
  const opts = { blockTag };
  const actual = await Promise.all([tm.borrowerOperations(opts), tm.collSurplusPool(opts), tm.musdToken(opts), bo.troveManager(opts), bo.collSurplusPool(opts), pool.borrowerOperationsAddress(opts), pool.troveManagerAddress(opts)]);
  const expected = [c.borrowerOperations,c.collSurplusPool,c.musd,c.troveManager,c.collSurplusPool,c.borrowerOperations,c.troveManager];
  if (!actual.every((a,i) => same(a,expected[i]))) throw new Error('Contract relationships do not match the configured deployment.');
  const token = new Contract(c.musd, ABI.token, provider);
  if (Number(await token.decimals(opts)) !== 18) throw new Error('Unexpected MUSD decimals.');
  return { chainId: NETWORK.chainId, codePresent: true, relationshipsMatch: true, note: 'Checks confirm chain, contract code presence and cross-references, not an audit or a guarantee of safety.' };
}
export async function inspectWallet(rawAddress) {
  const address = getAddress(rawAddress);
  return withProvider(async provider => {
    const head = await provider.getBlockNumber();
    // A short head offset reduces reorg exposure but does not assert finality.
    const blockNumber = Math.max(0, head - 2);
    const block = await provider.getBlock(blockNumber);
    if (!block) throw new Error('Snapshot block unavailable.');
    if (Date.now()/1000 - block.timestamp > 600) throw new Error('RPC snapshot is stale. Retry later.');
    const checks = await verifyDeployment(provider, blockNumber);
    const tm = new Contract(NETWORK.contracts.troveManager, ABI.tm, provider);
    const pool = new Contract(NETWORK.contracts.collSurplusPool, ABI.pool, provider);
    const token = new Contract(NETWORK.contracts.musd, ABI.token, provider);
    const opts = { blockTag: blockNumber };
    const [statusRaw, surplus, musd, btc] = await Promise.all([tm.getTroveStatus(address,opts),pool.getCollateral(address,opts),token.balanceOf(address,opts),provider.getBalance(address,blockNumber)]);
    const status = Number(statusRaw);
    let debt = null, collateral = null;
    if (status === 1) {
      // Getter's first three values already include pending redistribution.
      const entire = await tm.getEntireDebtAndColl(address,opts);
      collateral = formatUnits(entire[0],18);
      debt = formatUnits(entire[1]+entire[2],18);
    }
    return { mode:'live', address, status, ...describeStatus(status,surplus), surplusWei: surplus.toString(), surplus: formatUnits(surplus,18), musd: formatUnits(musd,18), btc: formatUnits(btc,18), debt, collateral, checks, blockNumber, blockHash:block.hash, blockTimestamp: block.timestamp, checkedAt:new Date().toISOString(), contracts:NETWORK.contracts, transactionEnabled:false, historyAvailable:false };
  });
}
