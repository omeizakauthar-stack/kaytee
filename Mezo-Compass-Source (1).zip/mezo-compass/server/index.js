import express from 'express';
import { isAddress } from 'ethers';
import { inspectWallet, withProvider } from './chain.js';
import { NETWORK } from '../src/network.js';
import { scanHistory, inspectTransaction } from './history.js';
import path from 'node:path';

const app = express();
app.disable('x-powered-by');
app.use('/api', (_req,res,next) => {res.set('Cache-Control','no-store'); next();});
const cache = new Map();
let concurrent = 0;
app.get('/api/network', async (_req,res) => {
  try { const block = await withProvider(p=>p.getBlockNumber()); res.json({name:NETWORK.name,chainId:NETWORK.chainId,block,transactionsEnabled:false}); }
  catch {res.status(503).json({error:'Mainnet RPC is unavailable. No cached or sample data is substituted.'});}
});
app.get('/api/inspect/:address', async (req,res) => {
  const address = req.params.address;
  if (!isAddress(address)) return res.status(400).json({error:'Enter a valid 0x wallet address (42 characters).'});
  const key = address.toLowerCase();
  const entry = cache.get(key);
  if (entry && Date.now()-entry.time < 15000) return res.json({...entry.value,cached:true});
  if (concurrent >= 5) return res.status(429).json({error:'Too many checks in progress. Please try again shortly.'});
  concurrent++;
  try {
    const value = await inspectWallet(address);
    if (cache.size >= 100) cache.delete(cache.keys().next().value);
    cache.set(key,{time:Date.now(),value});res.json(value);
  } catch(e) {
    console.error('Mainnet inspection failed:',e.shortMessage || e.message);
    res.status(503).json({error:'Could not verify mainnet data. No recovery amount can be confirmed. Please retry later.'});
  } finally {concurrent--;}
});
async function boundedRead(res, fn) {
  if(concurrent>=5)return res.status(429).json({error:'Too many checks in progress. Try again shortly.'});
  concurrent++;
  try{res.json(await fn());}
  catch(e){console.error('Evidence read failed:',e.shortMessage||e.message);res.status(503).json({error:'Could not verify these records. No events or recovery are assumed. Please retry.'});}
  finally{concurrent--;}
}
app.get('/api/history/:address',async(req,res)=>{
  if(!isAddress(req.params.address))return res.status(400).json({error:'Invalid wallet address.'});
  const raw=req.query.toBlock;
  if(raw!==undefined && (typeof raw!=='string'||!/^\d{1,10}$/.test(raw)))return res.status(400).json({error:'Invalid history cursor.'});
  await boundedRead(res,()=>scanHistory(req.params.address,raw===undefined?undefined:Number(raw)));
});
app.get('/api/transaction/:address/:hash',async(req,res)=>{
  if(!isAddress(req.params.address)||!/^0x[0-9a-fA-F]{64}$/.test(req.params.hash))return res.status(400).json({error:'Enter a valid wallet address and transaction hash.'});
  await boundedRead(res,()=>inspectTransaction(req.params.address,req.params.hash));
});
app.use('/api',(_req,res)=>res.status(404).json({error:'Not found'}));
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.resolve('dist')));
  app.get('*',(_req,res)=>res.sendFile(path.resolve('dist/index.html')));
} else {
  const { createServer } = await import('vite');
  const vite = await createServer({ server:{ middlewareMode:true, allowedHosts:true }, appType:'spa' });
  app.use(vite.middlewares);
}
app.listen(3000,'0.0.0.0',()=>console.log('Mezo Compass available on port 3000 — mainnet read-only; transactions disabled.'));
