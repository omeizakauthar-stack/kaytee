# Mezo Compass

A mainnet **read-only prototype** that helps a borrower understand their Mezo MUSD loan and check whether the protocol records unclaimed BTC collateral.

## Run

Node.js 20+:

```sh
npm ci
npm run dev
```

Open port 3000. Server binds to `0.0.0.0`. Browser API calls use same-origin `/api` URLs. The live preview is a development deployment, not permanent production hosting.

Production:

```sh
npm run build
npm start
```

The backend needs outbound HTTPS access to Mezo RPC providers. No wallet key or API key is needed.

## Working now

- Mezo mainnet chain 31612; BTC native gas.
- Paste a public address without wallet connection, or request its address from an injected EVM wallet.
- At one snapshot block: loan protocol status, CollSurplusPool balance, native BTC and MUSD balances.
- Active loan collateral/debt use `getEntireDebtAndColl`: first three return values already include pending redistribution; do not add pending values again.
- Check RPC chain ID, code presence at all four configured addresses, MUSD decimals, and selected contract cross-references.
- Plain-language distinction between full redemption, owner closure, liquidation, active loan, absent loan, and unknown status.
- Explorer evidence links, JSON snapshot export, official recovery instructions.
- Three explicitly fictional walkthroughs: redeemed, active, liquidated. Never substituted for failed live reads.
- Responsive desktop/mobile interface.

## Deliberately not implemented

**No transaction signing, broadcasting, claim simulation, token approval, automated claim, or fund custody.** The recovery button opens instructions. No new contracts were deployed. This is not an end-to-end recovery demo yet.

- No historical event indexing, actual event timeline, partial-redemption attribution, price feed, or liquidation forecast.
- No guarantee of recovery, financial advice, or independent audit.
- No demonstrated real borrower recovery or user validation yet. The zero address used in smoke tests is a public read-only diagnostic, not an eligible borrower or user wallet.
- Injected wallet connection is implemented; real wallet-extension compatibility still needs user testing.

## Verification and tests

```sh
npm test
npm run build
npm run test:live
# optional public address, no signing:
node scripts/verify-network.js 0xYOUR_PUBLIC_ADDRESS
# browser checks; start npm run dev first:
npx playwright install --with-deps chromium
node scripts/browser-check.js
```

Unit tests cover status attribution, independent surplus detection, unknown status, mainnet configuration and fictional-data safeguards. Browser checks cover desktop/mobile, navigation, examples, invalid address, mainnet read, locked claim explanation and no page errors or overflow. These are smoke tests, not a security audit. A positive-surplus real-wallet case has not been tested.

## Security and privacy

- No private keys, recovery phrases, secrets or real money are required to run the app.
- A wallet connection only requests public accounts (`eth_requestAccounts`); it does not request signatures or network switching.
- The server exposes GET-only API routes. It has no transaction submission endpoint.
- Selected snapshots use head minus two blocks, not asserted finality; a 10-minute staleness check fails closed. RPC providers remain a trust dependency; data is not independently proved.
- Proxy implementation code hashes are not pinned or audited. Contract relationship checks must not be described as full verification.
- An in-memory snapshot cache lasts 15 seconds, bounded to 100 entries, with five concurrent inspection requests. No database is used. This is not robust public-production rate limiting.
- Checked addresses pass through the app backend and public RPC providers; hosting infrastructure and providers may retain request logs.
- Walkthrough numbers are fictional. Exports include their mode and disclaimer.
- Never send BTC to an address offering to unlock recovery. Only the original owner can execute the protocol claim.

## Before enabling mainnet claims

1. Independent experienced smart-contract review; verify current proxy implementations and ABI compatibility.
2. Controlled integration tests, including a legitimate positive-surplus fixture; do not create risky mainnet loans just for a demo.
3. Bind inspected address to the connected wallet; re-check chain, accounts and current surplus immediately before signing.
4. Simulate `BorrowerOperations.claimCollateral()` from that account; estimate and disclose BTC gas. No ETH/BTC value, token approval or alternate recipient.
5. Handle cancellation, chain/account changes, pending transaction, replacement, reverts, confirmation and refreshed surplus.
6. Keep claims disabled if any check fails. Never treat a zero balance after an unrelated transaction as evidence of a successful claim.
7. Harden hosting, headers, rate limits, dependencies, privacy disclosures and monitoring.

## Source references

- Mainnet network: https://mezo.org/docs/developers/getting-started/
- Official claim guide: https://mezo.org/docs/users/borrow/claim-collateral-after-redemption/
- Official deployment artifacts and ABI: https://github.com/mezo-org/musd/tree/main/solidity/artifacts/deployments/mainnet
- Status enum and loan getter: https://github.com/mezo-org/musd/blob/main/solidity/contracts/interfaces/ITroveManager.sol and `TroveManager.sol`

The sourced mainnet deployment artifacts are saved in `docs/mainnet-*.json`. Earlier testnet research artifacts remain for reference but are not used by the application. Configuration lives in `src/network.js`.

## Hackathon work still needed

Validate the problem with borrowers and compare current Mezo UI and mezotools.cc; establish real differentiation; get organizer feedback on fit; complete safe claim flow with review; demonstrate a reproducible verified case; publish code and permanent hosting; prepare a two-minute video and deck. Do not represent this prototype as submission-ready or a guaranteed prize winner.
